import scrapy


class GongspiderSpider(scrapy.Spider):
    name = 'gongSpider'
    allowed_domains = ['12371.cn']
    start_urls = ['http://www.12371.cn/special/zt/']

    def parse(self, response):
        websites = response.xpath('//div[contains(@class,"dyw769_con02")]/div/ul/div/li/div')

        for website in websites:
            website_name = website.xpath('/a').extract()
            website_wangzi = website.xpath('/a/@href').extract()
            print(website_name)
            print(website_wangzi)